var menuItems = document.querySelectorAll("li.has-submenu");
Array.prototype.forEach.call(menuItems, function (el, i) {
  var activatingA = el.querySelector("a");
  var btn = 'show submenu for "' + activatingA.textContent + '"';
  activatingA.insertAdjacentHTML("afterend", btn);

  activatingA.addEventListener("click", function (event) {
    if (el.className == "has-submenu") {
      el.className = "has-submenu open";
      activatingA.setAttribute("aria-expanded", "true");
    } else {
      el.className = "has-submenu";
      activatingA.setAttribute("aria-expanded", "false");
    }
    event.preventDefault();
  });
});





 